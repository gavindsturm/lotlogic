export function getFees() {
  return 180; // example flat fee
}
